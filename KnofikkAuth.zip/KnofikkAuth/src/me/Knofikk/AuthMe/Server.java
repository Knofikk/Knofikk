package me.Knofikk.AuthMe;

public class Server implements Comparable<Server> {
    String server;
    int players;

    public Server(String server, int players) {
        this.server = server;
        this.players = players;
    }

    public int compareTo(Server server) {
        return server.getPlayers() - this.getPlayers();
    }

    public String getServer() {
        return this.server;
    }

    public int getPlayers() {
        return this.players;
    }

    public String toString() {
        return this.server + ";" + this.players;
    }
}
