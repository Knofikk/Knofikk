package me.Knofikk.AuthMe;

import com.google.common.collect.Maps;

import java.util.HashMap;

public class OnlyProxyJoin {
    public static HashMap<String, String> vdsServers = Maps.newLinkedHashMap();

}