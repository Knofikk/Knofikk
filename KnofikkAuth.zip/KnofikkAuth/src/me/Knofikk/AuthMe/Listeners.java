package me.Knofikk.AuthMe;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.weather.WeatherChangeEvent;

public class Listeners implements Listener {
    public Main plugin;
    public List<String> enabled_cmds = new ArrayList();

    public Listeners(Main pl) {
        this.plugin = pl;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player player = e.getPlayer();
        player.setGameMode(GameMode.ADVENTURE);
        e.setJoinMessage((String)null);
        Location loc = new Location(Bukkit.getWorld("world"), 75.644D, 100.0D, 127.678D, 134.7F, -3.3F);
        player.teleport(loc);
        e.getPlayer().setExp(-100.0F);
        e.getPlayer().setHealth(1.0D);
        e.getPlayer().setFoodLevel(20);
    }

    @EventHandler
    public void onHunger(FoodLevelChangeEvent e) {
        e.setCancelled(true);
        if (e.getEntity() instanceof Player) {
            ((Player)e.getEntity()).setFoodLevel(20);
            ((Player)e.getEntity()).setHealth(1.0D);
        }

    }

    @EventHandler
    public void onWeather(WeatherChangeEvent e) {
        e.setCancelled(true);
    }
}
